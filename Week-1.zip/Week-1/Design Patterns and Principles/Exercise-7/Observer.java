// Observer.java
package main;

interface Observer {
    void update(double stockPrice);
}
