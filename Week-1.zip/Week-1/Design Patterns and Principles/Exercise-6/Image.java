// src/Image.java
public interface Image {
    void display();
}
